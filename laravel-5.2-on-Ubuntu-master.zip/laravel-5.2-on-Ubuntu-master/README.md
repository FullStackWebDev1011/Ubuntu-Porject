# laravel-5.2-on-Ubuntu
install Laravel 5.2 on ubuntu

Complete instructions how to install Laravel 5.2 Framework on Ubuntu 16.04

watch video on Youtube:

https://www.youtube.com/watch?v=A6TdaRIsG6g
